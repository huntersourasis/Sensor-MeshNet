import serial
import time
import json
import requests

SERIAL_PORT = 'COM8'
BAUD_RATE = 115200

API_URL = "http://127.0.0.1:5000/api/data"

try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
    print(f"Connected to {SERIAL_PORT} at {BAUD_RATE} baud.")

    time.sleep(2)

    while True:
        if ser.in_waiting > 0:
            # 1. Read bytes and ignore weird startup hardware characters
            raw_bytes = ser.readline()
            line = raw_bytes.decode('utf-8', errors='ignore')
            
            # 2. Strip spaces, newlines, AND hidden C-array null bytes
            line = line.strip(' \r\n\t\x00')

            if not line:
                continue

            # 3. Find where the JSON starts and ends
            start_idx = line.find('{')
            end_idx = line.rfind('}')

            if start_idx != -1 and end_idx != -1:
                # Extract ONLY the JSON part, ignoring any surrounding text/garbage
                json_string = line[start_idx:end_idx+1]
                print(f"Extracted JSON: {json_string}")

                try:
                    data = json.loads(json_string)
                    response = requests.post(API_URL, json=data)

                    if response.status_code == 200:
                        print("Sent to API successfully!")
                    else:
                        print("API error:", response.text)

                except json.JSONDecodeError as e:
                    print(f"Still Invalid JSON: {e} -> Raw Line: {json_string}")
            else:
                # This will catch and print standard messages like "Bridge node initialized..."
                # without crashing the script.
                print("System Message:", line)

except serial.SerialException as e:
    print(f"Serial Error: {e}")

except KeyboardInterrupt:
    print("\nClosing connection...")

finally:
    if 'ser' in locals() and ser.is_open:
        ser.close()